window.powerBiEmbed = {
    renderReport: function (elementId, config) {
        const container = document.getElementById(elementId);

        if (!container) {
            throw new Error("Power BI container not found.");
        }

        const models = window['powerbi-client'].models;

        const embedConfig = {
            type: 'report',
            id: config.reportId,
            embedUrl: config.embedUrl,
            accessToken: config.accessToken,
            tokenType: models.TokenType.Embed,
            settings: {
                panes: {
                    filters: { visible: false },
                    pageNavigation: { visible: true }
                },
                background: models.BackgroundType.Transparent
            }
        };

        powerbi.reset(container);
        const report = powerbi.embed(container, embedConfig);

        report.on('loaded', function () {
            console.log('Power BI report loaded.');
        });

        report.on('rendered', function () {
            console.log('Power BI report rendered.');
        });

        report.on('error', function (event) {
            console.error('Power BI embed error', event.detail);
        });
    }
};
