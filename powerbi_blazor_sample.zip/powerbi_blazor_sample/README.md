# Blazor + Power BI Embedded sample

This sample shows the **app-owns-data** pattern for embedding a Power BI report inside a **Blazor Server / .NET 8** application.

## What this sample does

- Uses a **service principal** to authenticate server-side
- Calls the Power BI REST API to fetch the report metadata
- Generates an **embed token**
- Passes the token and embed URL to a Blazor component
- Embeds the report in the browser with the `powerbi-client` JavaScript library

## Setup

1. Create a Power BI workspace and publish a report.
2. Register a Microsoft Entra app.
3. Allow the service principal to use Power BI APIs and add it to the workspace.
4. Copy these values into `appsettings.json`:
   - `TenantId`
   - `ClientId`
   - `ClientSecret`
   - `WorkspaceId`
   - `ReportId`

## Run

```bash
dotnet restore
dotnet run
```

Then open the local URL shown in the terminal.

## Notes

- This sample keeps the secret and token generation on the server. Do not move token generation into browser code.
- For production, prefer a **certificate** instead of a client secret when possible.
- If your report uses RLS, you can extend the `GenerateEmbedTokenAsync` payload with `identities`.
