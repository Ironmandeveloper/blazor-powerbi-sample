namespace PowerBiEmbedded.BlazorSample.Services;

public sealed class EmbedConfig
{
    public string ReportId { get; set; } = string.Empty;
    public string EmbedUrl { get; set; } = string.Empty;
    public string AccessToken { get; set; } = string.Empty;
    public string TokenType { get; set; } = "Embed";
}
