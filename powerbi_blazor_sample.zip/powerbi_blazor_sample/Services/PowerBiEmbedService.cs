using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Options;

namespace PowerBiEmbedded.BlazorSample.Services;

public sealed class PowerBiEmbedService
{
    private const string PowerBiScope = "https://analysis.windows.net/powerbi/api/.default";

    private readonly IHttpClientFactory _httpClientFactory;
    private readonly PowerBiOptions _options;

    public PowerBiEmbedService(
        IHttpClientFactory httpClientFactory,
        IOptions<PowerBiOptions> options)
    {
        _httpClientFactory = httpClientFactory;
        _options = options.Value;
    }

    public async Task<EmbedConfig> GetEmbedConfigAsync()
    {
        ValidateOptions();

        var aadToken = await GetAzureAdAccessTokenAsync();
        var report = await GetReportAsync(aadToken);
        var embedToken = await GenerateEmbedTokenAsync(aadToken, report.DatasetId);

        return new EmbedConfig
        {
            ReportId = report.Id,
            EmbedUrl = report.EmbedUrl,
            AccessToken = embedToken.Token,
            TokenType = "Embed"
        };
    }

    private void ValidateOptions()
    {
        var missing = new List<string>();

        if (string.IsNullOrWhiteSpace(_options.TenantId)) missing.Add(nameof(_options.TenantId));
        if (string.IsNullOrWhiteSpace(_options.ClientId)) missing.Add(nameof(_options.ClientId));
        if (string.IsNullOrWhiteSpace(_options.ClientSecret)) missing.Add(nameof(_options.ClientSecret));
        if (string.IsNullOrWhiteSpace(_options.WorkspaceId)) missing.Add(nameof(_options.WorkspaceId));
        if (string.IsNullOrWhiteSpace(_options.ReportId)) missing.Add(nameof(_options.ReportId));

        if (missing.Count > 0)
        {
            throw new InvalidOperationException(
                $"Missing Power BI configuration: {string.Join(", ", missing)}");
        }
    }

    private async Task<string> GetAzureAdAccessTokenAsync()
    {
        using var client = _httpClientFactory.CreateClient();

        var tokenEndpoint =
            $"https://login.microsoftonline.com/{_options.TenantId}/oauth2/v2.0/token";

        var form = new Dictionary<string, string>
        {
            ["grant_type"] = "client_credentials",
            ["client_id"] = _options.ClientId,
            ["client_secret"] = _options.ClientSecret,
            ["scope"] = PowerBiScope
        };

        using var response = await client.PostAsync(
            tokenEndpoint,
            new FormUrlEncodedContent(form));

        var json = await response.Content.ReadAsStringAsync();

        if (!response.IsSuccessStatusCode)
        {
            throw new InvalidOperationException(
                $"Could not get Azure AD token. {response.StatusCode}: {json}");
        }

        using var document = JsonDocument.Parse(json);
        return document.RootElement.GetProperty("access_token").GetString()
               ?? throw new InvalidOperationException("Access token missing in Azure AD response.");
    }

    private async Task<PowerBiReportResponse> GetReportAsync(string aadToken)
    {
        using var client = _httpClientFactory.CreateClient();
        client.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("Bearer", aadToken);

        var url =
            $"https://api.powerbi.com/v1.0/myorg/groups/{_options.WorkspaceId}/reports/{_options.ReportId}";

        using var response = await client.GetAsync(url);
        var json = await response.Content.ReadAsStringAsync();

        if (!response.IsSuccessStatusCode)
        {
            throw new InvalidOperationException(
                $"Could not read report metadata. {response.StatusCode}: {json}");
        }

        var report = JsonSerializer.Deserialize<PowerBiReportResponse>(
            json,
            new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

        return report ?? throw new InvalidOperationException("Report metadata was empty.");
    }

    private async Task<GenerateTokenResponse> GenerateEmbedTokenAsync(
        string aadToken,
        string datasetId)
    {
        using var client = _httpClientFactory.CreateClient();
        client.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("Bearer", aadToken);

        var request = new
        {
            reports = new[]
            {
                new { id = _options.ReportId }
            },
            datasets = new[]
            {
                new { id = datasetId }
            },
            targetWorkspaces = new[]
            {
                new { id = _options.WorkspaceId }
            }
        };

        var json = JsonSerializer.Serialize(request);
        using var content = new StringContent(json, Encoding.UTF8, "application/json");

        using var response = await client.PostAsync(
            "https://api.powerbi.com/v1.0/myorg/GenerateToken",
            content);

        var responseJson = await response.Content.ReadAsStringAsync();

        if (!response.IsSuccessStatusCode)
        {
            throw new InvalidOperationException(
                $"Could not generate embed token. {response.StatusCode}: {responseJson}");
        }

        var result = JsonSerializer.Deserialize<GenerateTokenResponse>(
            responseJson,
            new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

        return result ?? throw new InvalidOperationException("Embed token response was empty.");
    }

    private sealed class PowerBiReportResponse
    {
        public string Id { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string EmbedUrl { get; set; } = string.Empty;
        public string DatasetId { get; set; } = string.Empty;
    }

    private sealed class GenerateTokenResponse
    {
        public string Token { get; set; } = string.Empty;
        public string TokenId { get; set; } = string.Empty;
        public DateTimeOffset Expiration { get; set; }
    }
}
